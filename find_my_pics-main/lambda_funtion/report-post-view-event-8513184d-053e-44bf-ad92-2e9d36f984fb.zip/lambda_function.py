import json
from redis import Redis

redis_client = Redis(host="ece1779.pp3tgv.ng.0001.use1.cache.amazonaws.com", port="6379", decode_responses=True)
def lambda_handler(event, context):
    # for CORS preflight request
    if event['httpMethod'] == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, GET',
                'Access-Control-Allow-Origin': '*',
            }
        }
    # for normal 
    statusCode = 200
    request_body = json.loads(event["body"])
    if "post_id" in request_body:
        post_id = request_body["post_id"]
        value = {"value": add_post_view(post_id)}
    else:
        statusCode = 400
        value = {"error": "Bad Request", "msg": "No post_id provided"}
    headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': '*',
        'Access-Control-Allow-Methods': '*',
        'Content-Type': 'application/json'
    }
    return {
        'statusCode': statusCode,
        'headers': headers,
        'body': json.dumps(value)
    }

def add_post_view(post_id):
    return redis_client.incr("post_views:" + post_id, 1)
