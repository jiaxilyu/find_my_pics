import json
from urllib.parse import parse_qs
from redis import Redis

redis_client = Redis(host="ece1779.pp3tgv.ng.0001.use1.cache.amazonaws.com", port="6379", decode_responses=True)
def lambda_handler(event, context):
    # for CORS preflight request
    if event['httpMethod'] == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, GET',
                'Access-Control-Allow-Origin': '*',
            }
        }
    # for normal requests
    statusCode = 200
    query_params = event['queryStringParameters']
    if "post_id" in query_params:
        post_id = query_params["post_id"]
        value = {"value": int(get_post_view(post_id))}
    else:
        statusCode = 400
        value = {"error": "Bad Request", "msg": "No post_id provided"}
    headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, GET',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Content-Type': 'application/json'
    }
    return {
        'statusCode': statusCode,
        'headers': headers,
        'body': json.dumps(value)
    }

def get_post_view(post_id):
    amount = redis_client.get("post_views:" + post_id)
    return amount if amount else 0
